# OMR Institutes Project

Power BI project analysing institutes along the OMR (Old Mahabalipuram Road), Chennai.

## Files
- `OMR_Plan.docx` - project plan
- `OMR_Project_Power_BI_Dashboard_Design.docx` - dashboard design document
- `OMR_Institudes_Final_Data.xlsx` - final cleaned dataset
- `omr_institutes.pbix` - Power BI report (open with Power BI Desktop)
